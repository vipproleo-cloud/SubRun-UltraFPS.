# Sub Run Ultra FPS — gerar APK

Este projeto gera um APK de teste (debug) automaticamente pelo GitHub Actions.

## Como usar pelo tablet

1. Entre em github.com e faça login.
2. Crie um repositório novo chamado `SubRun-UltraFPS`.
3. Extraia este ZIP no tablet.
4. No repositório, use **Add file → Upload files** e envie os arquivos e pastas extraídos, mantendo a estrutura (`app`, `.github`, `build.gradle`, `settings.gradle`, etc.).
5. Confirme em **Commit changes**.
6. Abra a aba **Actions** do repositório e selecione o fluxo **Build Android APK**.
7. Quando terminar com sucesso, abra a execução e baixe o artefato `SubRun-UltraFPS-APK`.
8. O download do artefato é um ZIP; dentro dele estará `app-debug.apk`, que pode ser instalado diretamente.

O APK é uma compilação debug para testes, não uma publicação assinada para a Play Store.
